#pragma once
int criarUsuario(char usuario[21], char senha[16], int perfil);
int ultimoCodUsuario();
