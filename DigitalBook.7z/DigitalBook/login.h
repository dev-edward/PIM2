int verificarUsuario(char usuario[21]);
int compararSenha(char senha[15]);
int usuarioAtivo();
int usuarioCodigo();
