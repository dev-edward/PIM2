int abertura();
int cabecalho();
